# -*- coding: utf-8 -*-

import wx
import os
import threading
import tempfile
import winsound
from pydub import AudioSegment
from moviepy.editor import VideoFileClip, AudioFileClip, CompositeVideoClip
from helper_functions import text_to_speech, parse_srt_file, extract_audio_from_video
import pyttsx3

# "conversion" adlı bir dizin yoksa oluşturulur
if not os.path.exists('conversion'):
    os.makedirs('conversion')

class AppFrame(wx.Frame):
    def __init__(self, *args, **kw):
        super(AppFrame, self).__init__(*args, **kw)
        self.engine = pyttsx3.init()  # Ses motorunu burada başlatıyoruz
        self.init_ui()  # Kullanıcı arayüzünü başlatır

    def init_ui(self):
        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)

        # SRT dosyasını seçmek için buton
        self.chooseSrtBtn = wx.Button(panel, label="SRT Seç")
        self.chooseSrtBtn.Bind(wx.EVT_BUTTON, self.on_choose_srt)
        sizer.Add(self.chooseSrtBtn, 0, flag=wx.EXPAND)
        self.srtPathText = wx.StaticText(panel, label="Seçilen SRT: ")
        sizer.Add(self.srtPathText, 0, flag=wx.EXPAND)

        # Video dosyasını seçmek için buton
        self.chooseVideoBtn = wx.Button(panel, label="Video Seç (MP4)")
        self.chooseVideoBtn.Bind(wx.EVT_BUTTON, self.on_choose_video)
        sizer.Add(self.chooseVideoBtn, 0, flag=wx.EXPAND)
        self.videoPathText = wx.StaticText(panel, label="Seçilen Video: ")
        sizer.Add(self.videoPathText, 0, flag=wx.EXPAND)

        # Ses seviyesi için kaydırıcı
        self.volumeLabel = wx.StaticText(panel, label="Ses Seviyesi (0-100):")
        sizer.Add(self.volumeLabel, 0, flag=wx.EXPAND)
        self.volumeSlider = wx.Slider(panel, value=100, minValue=0, maxValue=100, style=wx.SL_HORIZONTAL)
        sizer.Add(self.volumeSlider, 0, flag=wx.EXPAND)

        # Konuşma hızı için kaydırıcı
        self.rateLabel = wx.StaticText(panel, label="Konuşma Hızı (50-300):")
        sizer.Add(self.rateLabel, 0, flag=wx.EXPAND)
        self.rateSlider = wx.Slider(panel, value=200, minValue=50, maxValue=300, style=wx.SL_HORIZONTAL)
        sizer.Add(self.rateSlider, 0, flag=wx.EXPAND)

        # SAPI5 ses ayarları için giriş alanı
        self.sapi5VoiceLabel = wx.StaticText(panel, label="SAPI5 Ses Ayarları:")
        sizer.Add(self.sapi5VoiceLabel, 0, flag=wx.EXPAND)
        self.sapi5VoiceCtrl = wx.TextCtrl(panel)
        sizer.Add(self.sapi5VoiceCtrl, 0, flag=wx.EXPAND)

        # Ses seçim radyo butonları
        self.voiceLabel = wx.StaticText(panel, label="Ses Seçimi:")
        sizer.Add(self.voiceLabel, 0, flag=wx.EXPAND)
        self.voiceRadioBox = wx.RadioBox(panel, choices=self.get_voice_names(), style=wx.RA_SPECIFY_COLS)
        sizer.Add(self.voiceRadioBox, 0, flag=wx.EXPAND)

        # Deneme metni için giriş alanı
        self.testTextLabel = wx.StaticText(panel, label="Deneme İçeriği:")
        sizer.Add(self.testTextLabel, 0, flag=wx.EXPAND)
        self.testTextCtrl = wx.TextCtrl(panel, value="Bu bir deneme metnidir.")
        sizer.Add(self.testTextCtrl, 0, flag=wx.EXPAND)

        # TTS önizleme dosyası oluştur butonu
        self.createTTSPreviewBtn = wx.Button(panel, label="TTS Önizleme Dosyasını Oluştur")
        self.createTTSPreviewBtn.Bind(wx.EVT_BUTTON, self.on_create_tts_preview)
        sizer.Add(self.createTTSPreviewBtn, 0, flag=wx.EXPAND)

        # TTS dosyasını açma butonu
        self.openTTSFileBtn = wx.Button(panel, label="TTS Dosyasını Aç")
        self.openTTSFileBtn.Bind(wx.EVT_BUTTON, self.on_open_tts_file)
        sizer.Add(self.openTTSFileBtn, 0, flag=wx.EXPAND)

        # Video sesi için kaydırıcı
        self.videoVolumeLabel = wx.StaticText(panel, label="Video Ses Seviyesi (0-100):")
        sizer.Add(self.videoVolumeLabel, 0, flag=wx.EXPAND)
        self.videoVolumeSlider = wx.Slider(panel, value=100, minValue=0, maxValue=100, style=wx.SL_HORIZONTAL)
        sizer.Add(self.videoVolumeSlider, 0, flag=wx.EXPAND)

        # Video önizleme dosyası oluştur butonu
        self.createVideoPreviewBtn = wx.Button(panel, label="Video Önizleme Dosyasını Oluştur")
        self.createVideoPreviewBtn.Bind(wx.EVT_BUTTON, self.on_create_video_preview)
        sizer.Add(self.createVideoPreviewBtn, 0, flag=wx.EXPAND)

        # Video dosyasını açma butonu
        self.openVideoFileBtn = wx.Button(panel, label="Video Dosyasını Aç")
        self.openVideoFileBtn.Bind(wx.EVT_BUTTON, self.on_open_video_file)
        sizer.Add(self.openVideoFileBtn, 0, flag=wx.EXPAND)

        # Dönüştürme işlemini başlatan buton
        self.convertBtn = wx.Button(panel, label="Dönüştür")
        self.convertBtn.Bind(wx.EVT_BUTTON, self.on_convert)
        sizer.Add(self.convertBtn, 0, flag=wx.EXPAND)

        # Çıktı formatı radyo butonları
        self.outputFormatLabel = wx.StaticText(panel, label="Çıktı Formatı:")
        sizer.Add(self.outputFormatLabel, 0, flag=wx.EXPAND)
        self.outputFormatRadioBox = wx.RadioBox(panel, choices=["MP3", "MP4"], style=wx.RA_SPECIFY_COLS)
        sizer.Add(self.outputFormatRadioBox, 0, flag=wx.EXPAND)

        # İlerleme göstergesi
        self.progress = wx.Gauge(panel, range=100, size=(-1, 30), style=wx.GA_HORIZONTAL)
        sizer.Add(self.progress, 0, flag=wx.EXPAND)

        # Durum mesajlarını gösteren metin alanı
        self.status = wx.TextCtrl(panel, style=wx.TE_READONLY | wx.TE_MULTILINE)
        sizer.Add(self.status, 1, flag=wx.EXPAND)

        panel.SetSizer(sizer)

        self.srt_path = ""
        self.video_path = ""
        self.preview_tts_file = ""
        self.preview_video_file = ""

    # Ses seçim kutusunu dolduran fonksiyon
    def get_voice_names(self):
        voices = self.engine.getProperty('voices')
        return [voice.name for voice in voices]

    # TTS önizleme dosyası oluşturma işlemini başlatan fonksiyon
    def on_create_tts_preview(self, event):
        self.status.AppendText("TTS önizleme dosyası oluşturuluyor...\n")
        self.createTTSPreviewBtn.Disable()
        threading.Thread(target=self.create_tts_preview).start()

    # TTS önizleme dosyasını oluşturma işlemi
    def create_tts_preview(self):
        try:
            text = self.testTextCtrl.GetValue()
            volume = self.volumeSlider.GetValue() / 100
            rate = self.rateSlider.GetValue()
            selected_voice = self.voiceRadioBox.GetStringSelection()

            if selected_voice:
                for voice in self.engine.getProperty('voices'):
                    if voice.name == selected_voice:
                        self.engine.setProperty('voice', voice.id)
                        break

            self.engine.setProperty('rate', rate)
            self.engine.setProperty('volume', volume)

            preview_filename = os.path.join("conversion", "preview.wav")
            self.engine.save_to_file(text, preview_filename)
            self.engine.runAndWait()

            self.preview_tts_file = preview_filename
            wx.CallAfter(self.update_status, f"TTS önizleme dosyası oluşturuldu: {preview_filename}")
        finally:
            wx.CallAfter(self.createTTSPreviewBtn.Enable)

    # TTS dosyasını açma fonksiyonu
    def on_open_tts_file(self, event):
        if self.preview_tts_file:
            os.startfile(os.path.dirname(self.preview_tts_file))
        else:
            self.update_status("Henüz bir TTS önizleme dosyası oluşturulmadı.\n")

    # SRT dosyasını seçen fonksiyon
    def on_choose_srt(self, event):
        fileDialog = wx.FileDialog(self, "Bir SRT dosyası seçin", wildcard="SRT dosyaları (*.srt)|*.srt", style=wx.FD_OPEN)
        if fileDialog.ShowModal() == wx.ID_OK:
            self.srt_path = fileDialog.GetPath()
            self.srtPathText.SetLabel(f"Seçilen SRT: {self.srt_path}")
            self.status.AppendText(f"Seçilen SRT: {self.srt_path}\n")

    # Video dosyasını seçen fonksiyon
    def on_choose_video(self, event):
        fileDialog = wx.FileDialog(self, "Bir video dosyası seçin", wildcard="MP4 dosyaları (*.mp4)|*.mp4", style=wx.FD_OPEN)
        if fileDialog.ShowModal() == wx.ID_OK:
            self.video_path = fileDialog.GetPath()
            self.videoPathText.SetLabel(f"Seçilen Video: {self.video_path}")
            self.status.AppendText(f"Seçilen Video: {self.video_path}\n")

    # Video önizleme dosyası oluşturma işlemini başlatan fonksiyon
    def on_create_video_preview(self, event):
        self.status.AppendText("Video önizleme dosyası oluşturuluyor...\n")
        self.createVideoPreviewBtn.Disable()
        threading.Thread(target=self.create_video_preview).start()

    # Video önizleme dosyasını oluşturma işlemi
    def create_video_preview(self):
        try:
            if not self.video_path:
                wx.CallAfter(self.update_status, "Lütfen bir video dosyası seçin.\n")
                return

            # Video dosyasının ortasından 20 saniyelik bir kesit alın
            video = VideoFileClip(self.video_path)
            start_time = max(0, (video.duration / 2) - 10)
            end_time = min(video.duration, start_time + 20)
            video_clip = video.subclip(start_time, end_time)

            # Videodan ses çıkar ve ses seviyesini ayarla
            video_audio = video_clip.audio
            video_audio_path = os.path.join("conversion", "temp_audio.wav")
            video_audio.write_audiofile(video_audio_path)

            video_audio_segment = AudioSegment.from_wav(video_audio_path)
            video_volume = self.videoVolumeSlider.GetValue() / 100
            adjusted_audio_segment = video_audio_segment + (video_volume * 20 - 10)

            adjusted_audio_path = os.path.join("conversion", "adjusted_audio.wav")
            adjusted_audio_segment.export(adjusted_audio_path, format="wav")

            # Videoyu ayarlanan ses ile yeniden birleştir
            adjusted_audio = AudioFileClip(adjusted_audio_path)
            final_video_clip = video_clip.set_audio(adjusted_audio)

            preview_video_path = os.path.join("conversion", "preview_video.mp4")
            final_video_clip.write_videofile(preview_video_path, codec='libx264', audio_codec='aac')

            self.preview_video_file = preview_video_path
            wx.CallAfter(self.update_status, f"Video önizleme dosyası oluşturuldu: {preview_video_path}\n")
        finally:
            wx.CallAfter(self.createVideoPreviewBtn.Enable)
            # Geçici dosyaları temizle
            if os.path.exists(video_audio_path):
                os.remove(video_audio_path)
            if os.path.exists(adjusted_audio_path):
                os.remove(adjusted_audio_path)

    # Video dosyasını açma fonksiyonu
    def on_open_video_file(self, event):
        if self.preview_video_file:
            os.startfile(os.path.dirname(self.preview_video_file))
        else:
            self.update_status("Henüz bir video önizleme dosyası oluşturulmadı.\n")

    # Dönüştürme işlemini başlatan fonksiyon
    def on_convert(self, event):
        if not self.srt_path or not self.video_path:
            wx.MessageBox("Lütfen hem bir SRT hem de bir video dosyası seçin.", "Hata", wx.OK | wx.ICON_ERROR)
            return

        self.convertBtn.Disable()
        self.status.AppendText("Dönüştürme işlemi başlatılıyor...\n")
        threading.Thread(target=self.perform_conversion).start()

    # Dönüştürme işlemini gerçekleştiren fonksiyon
    def perform_conversion(self):
        try:
            volume = self.volumeSlider.GetValue() / 100
            rate = self.rateSlider.GetValue()
            video_volume = self.videoVolumeSlider.GetValue() / 100
            output_format = self.outputFormatRadioBox.GetStringSelection()
            selected_voice = self.voiceRadioBox.GetStringSelection()

            wx.CallAfter(self.update_status, "İşlemler gerçekleştiriliyor...\n")

            wx.CallAfter(self.update_status, "SRT dosyası ayrıştırılıyor...\n")
            captions = parse_srt_file(self.srt_path)
            total_captions = len(captions)
            wx.CallAfter(self.update_status, f"{total_captions} altyazı satırı bulundu.\n")

            wx.CallAfter(self.update_status, "Video dosyasından ses çıkarılıyor...\n")
            video_audio_path = extract_audio_from_video(self.video_path)

            audio_clips = []
            for index, entry in enumerate(captions):
                wx.CallAfter(self.update_status, f"Altyazı {index + 1}/{total_captions} işleniyor...\n")
                text = entry['text']
                audio_filename = os.path.join("conversion", f"temp_tts_{index}.wav")
                text_to_speech(text, audio_filename, volume, rate, selected_voice)
                tts_audio = AudioSegment.from_wav(audio_filename)

                # Altyazı başlangıcına kadar olan sessizlik
                silence_before = (entry['start'].total_seconds() - sum([clip.duration_seconds for clip in audio_clips])) * 1000
                # Altyazı bitişinden sonraki sessizlik
                silence_after = (entry['end'].total_seconds() - entry['start'].total_seconds() - tts_audio.duration_seconds) * 1000

                audio_clips.append(AudioSegment.silent(duration=silence_before))
                audio_clips.append(tts_audio)
                audio_clips.append(AudioSegment.silent(duration=silence_after))
                wx.CallAfter(self.update_progress, int((index + 1) / total_captions * 100))

            wx.CallAfter(self.update_status, "TTS ve video sesleri birleştiriliyor...\n")
            video_audio = AudioSegment.from_wav(video_audio_path)
            video_audio = video_audio - (1.0 - video_volume) * 20  # Video sesini ayarla
            final_audio = video_audio.overlay(sum(audio_clips))

            if output_format == "MP3":
                final_audio_path = os.path.join("conversion", "final_output.mp3")
                final_audio.export(final_audio_path, format="mp3")
                wx.CallAfter(self.update_status, f"İşlemler tamamlandı! Çıktı dosyası: {final_audio_path}\n")
            else:
                final_audio_path = os.path.join("conversion", "final_output.mp3")
                final_audio.export(final_audio_path, format="mp3")

                # Video sesini değiştir ve yeni sesli video oluştur
                video_clip = VideoFileClip(self.video_path)
                final_audio_clip = AudioFileClip(final_audio_path)
                final_video_clip = video_clip.set_audio(final_audio_clip)

                final_video_path = os.path.join("conversion", "final_output.mp4")
                final_video_clip.write_videofile(final_video_path, codec='libx264', audio_codec='aac')

                wx.CallAfter(self.update_status, f"İşlemler tamamlandı! Çıktı dosyası: {final_video_path}\n")

                # Geçici dosyaları sil
                os.remove(final_audio_path)

            os.remove(video_audio_path)
            for index in range(total_captions):
                os.remove(os.path.join("conversion", f"temp_tts_{index}.wav"))

        finally:
            wx.CallAfter(self.convertBtn.Enable)
            # İşlem bittiğinde varsayılan Windows sesini çal
            winsound.MessageBeep(winsound.MB_OK)

    # İlerleme durumunu güncelleyen fonksiyon
    def update_progress(self, value):
        wx.CallAfter(self.progress.SetValue, value)

    # Durum mesajlarını güncelleyen fonksiyon
    def update_status(self, message):
        wx.CallAfter(self.status.AppendText, message)

if __name__ == "__main__":
    app = wx.App(False)
    frame = AppFrame(None, title="SRT'den Ses'e v1.1", size=(600, 700))
    frame.Show()
    app.MainLoop()
