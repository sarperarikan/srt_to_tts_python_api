import re
import os
import pyttsx3
from datetime import timedelta
from pydub import AudioSegment
from moviepy.editor import VideoFileClip, concatenate_videoclips

def parse_time(time_str):
    """
    SRT dosyasındaki zaman damgalarını timedelta objesine dönüştürür.
    Örnek: "00:01:23,456" -> timedelta(hours=0, minutes=1, seconds=23, milliseconds=456)
    """
    hours, minutes, seconds_milliseconds = time_str.split(':')
    seconds, milliseconds = seconds_milliseconds.split(',')
    return timedelta(hours=int(hours), minutes=int(minutes), seconds=int(seconds), milliseconds=int(milliseconds))

def parse_srt_file(srt_path):
    """
    SRT dosyasını okuyup, altyazı bloklarına ayırır ve her bir bloktaki zaman ve metin bilgilerini ayıklar.
    Giriş: SRT dosya yolu
    Çıkış: Altyazı bilgilerini içeren bir liste
    [{'start': timedelta(...), 'end': timedelta(...), 'text': '...'}, ...]
    """
    with open(srt_path, 'r', encoding='utf-8') as f:
        srt_content = f.read()
    srt_blocks = list(filter(None, srt_content.split('\n\n')))
    captions = []
    for block in srt_blocks:
        number, time_range, *text_lines = block.split('\n')
        start_time_str, _, end_time_str = time_range.split()
        start_time = parse_time(start_time_str)
        end_time = parse_time(end_time_str)
        captions.append({
            'start': start_time,
            'end': end_time,
            'text': ' '.join(text_lines)
        })
    return captions

def text_to_speech(text, filename, volume=1.0, rate=200, voice=None):
    """
    Verilen metni belirli bir ses seviyesinde ve hızda sesli dosyaya dönüştürür.
    Giriş: text (metin), filename (sesli dosya adı), volume (ses seviyesi), rate (konuşma hızı), voice (SAPI5 sesi)
    """
    engine = pyttsx3.init()
    if voice:
        engine.setProperty('voice', voice)
    engine.setProperty('volume', volume)
    engine.setProperty('rate', rate)
    engine.save_to_file(text, filename)
    engine.runAndWait()

def extract_audio_from_video(video_path):
    """
    Video dosyasından ses parçasını çıkarır ve geçici bir WAV dosyasına kaydeder.
    Giriş: Video dosya yolu
    Çıkış: Ses dosyası yolu (WAV)
    """
    video = VideoFileClip(video_path)
    audio_path = os.path.join("conversion", "temp_video_audio.wav")
    video.audio.write_audiofile(audio_path, codec='pcm_s16le')
    return audio_path

def merge_audio_with_srt(video_path, srt_path, volume=1.0, rate=200, voice=None, video_volume=1.0, output_format="mp3"):
    """
    Video dosyasındaki sesle SRT dosyasındaki metinleri birleştirir ve yeni bir sesli dosya oluşturur.
    Giriş: video_path (video dosya yolu), srt_path (SRT dosya yolu), volume (ses seviyesi), rate (konuşma hızı), voice (SAPI5 sesi), output_format (çıktı formatı)
    Çıkış: Nihai ses dosyası yolu (MP3/MP4)
    """
    video_audio_path = extract_audio_from_video(video_path)
    captions = parse_srt_file(srt_path)
    audio_clips = []
    total_captions = len(captions)
    
    for index, entry in enumerate(captions):
        text = entry['text']
        audio_filename = os.path.join("conversion", f"temp_tts_{index}.wav")
        text_to_speech(text, audio_filename, volume, rate, voice)
        tts_audio = AudioSegment.from_wav(audio_filename)
        
        # Altyazı başlangıcına kadar olan sessizlik
        silence_before = (entry['start'].total_seconds() - sum([clip.duration_seconds for clip in audio_clips])) * 1000
        # Altyazı bitişinden sonraki sessizlik
        silence_after = (entry['end'].total_seconds() - entry['start'].total_seconds() - tts_audio.duration_seconds) * 1000
        
        audio_clips.append(AudioSegment.silent(duration=silence_before))
        audio_clips.append(tts_audio)
        audio_clips.append(AudioSegment.silent(duration=silence_after))
    
    combined_tts_audio = sum(audio_clips, AudioSegment.empty())
    video_audio = AudioSegment.from_wav(video_audio_path).apply_gain(video_volume)
    final_audio = video_audio.overlay(combined_tts_audio)
    
    final_audio_path = os.path.join("conversion", f"final_output.{output_format}")
    final_audio.export(final_audio_path, format=output_format)
    
    # Geçici dosyaları sil
    os.remove(video_audio_path)
    for index in range(total_captions):
        os.remove(os.path.join("conversion", f"temp_tts_{index}.wav"))
    
    return final_audio_path
