import pyttsx3
import pysrt
from pydub import AudioSegment
from pydub.silence import split_on_silence
import os

def add_silence_between_subtitles(subs):
    output_path = os.path.join('output')

    # Kontrol için output_path dizinini oluşturuyoruz
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    audio = AudioSegment.empty()
    previous_end = 0

    for i, sub in enumerate(subs):
        # Alt yazı metnini ses dosyasına dönüştürür
        speech_text = sub.text.strip()
        if speech_text:
            engine = pyttsx3.init()
            output_file = os.path.join(output_path, f'{i}.wav')
            engine.save_to_file(speech_text, output_file)
            engine.runAndWait()

            # Oluşturulan ses dosyasını yükler
            speech_audio = AudioSegment.from_wav(output_file)

            # Sessizlik süresini hesaplamak için önceki bitiş süresi ve şu anki başlangıç süresi arasındaki fark alınır
            silence_duration = sub.start - previous_end

            # Sessizlik segmenti oluşturulur ve ana audio segmentine eklenir
            silent_segment = AudioSegment.silent(duration=silence_duration.seconds * 1000)
            audio += silent_segment

            # Ses segmenti ana audio segmentine eklenir
            audio += speech_audio

            # Şu anki bitiş süresi bir sonraki başlangıç süresi için önceki bitiş süresi olarak güncellenir
            previous_end = sub.end

    # Oluşan audio dosyasını kaydet
    output_file = os.path.join(output_path, 'video.wav')
    audio.export(output_file, format='wav')

    print("İşlem başarıyla tamamlandı.")

    # Ses dosyasını alt yazılarla uyumlu hale getir
    align_audio_with_subtitles(output_file, subs)


def align_audio_with_subtitles(audio_file, subs):
    # Ses dosyasını yükler
    audio = AudioSegment.from_wav(audio_file)

    output_path = os.path.join('output')

    # Kontrol için output_path dizinini oluşturuyoruz
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    output_file = os.path.join(output_path, 'aligned_audio.wav')

    aligned_audio = AudioSegment.silent(duration=subs[0].start.seconds * 1000)

    for i, sub in enumerate(subs):
        start_time = sub.start.seconds * 1000
        end_time = sub.end.seconds * 1000

        # Alt yazı süresi ile aynı süredeki ses segmentini alır
        subtitle_audio = audio[start_time:end_time]

        # Alt yazı süresi ile aynı süredeki sessizlik segmentini alır
        silence = AudioSegment.silent(duration=len(subtitle_audio))

        # Sessizlik segmenti ve alt yazı ses segmenti sırasıyla eklenir
        aligned_audio += silence + subtitle_audio

    # Kalan süre boyunca sessizlik eklenir
    remaining_duration = len(audio) - subs[-1].end.seconds * 1000
    silence_remaining = AudioSegment.silent(duration=remaining_duration)
    aligned_audio += silence_remaining

    # Uyumsuzlukları düzeltmek için sesten sessiz bölümleri ayırır
    chunks = split_on_silence(aligned_audio, min_silence_len=1000, silence_thresh=-30, keep_silence=100)

    # Sessiz bölümleri birleştirerek uyumlu ses dosyasını oluşturur
    output_audio = AudioSegment.empty()
    for chunk in chunks:
        output_audio += chunk

    # Uyumlu ses dosyasını kaydet
    output_file = os.path.join(output_path, 'aligned_audio.wav')
    output_audio.export(output_file, format='wav')

    print("İşlem başarıyla tamamlandı.")

# Alt yazıları yükleyin (örnek olarak srt dosyası kullanılmıştır)
subs = pysrt.open(os.path.join('files','video.srt'),encoding='utf-8')

# Alt yazılar arasına sessizlik ekleyerek ses dosyasını oluşturun
add_silence_between_subtitles(subs)
